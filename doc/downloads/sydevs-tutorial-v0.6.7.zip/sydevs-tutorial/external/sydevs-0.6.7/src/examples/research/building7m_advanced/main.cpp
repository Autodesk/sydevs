#include <examples/research/building7m_advanced/building7m.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::building7m();
    return 0;
}
