#include <examples/test_systems/sorting/sorting_systems.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::sorting_systems();
    return 0;
}
