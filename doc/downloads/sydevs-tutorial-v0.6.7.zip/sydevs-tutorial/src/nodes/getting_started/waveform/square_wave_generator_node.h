#pragma once
#ifndef SYDEVS_TUTORIAL_SQUARE_WAVE_GENERATOR_NODE_H_
#define SYDEVS_TUTORIAL_SQUARE_WAVE_GENERATOR_NODE_H_

#include <sydevs/systems/atomic_node.h>

namespace sydevs_tutorial {

using namespace sydevs;
using namespace sydevs::systems;


class square_wave_generator_node : public atomic_node
{
public:
    // Constructor/Destructor:
    square_wave_generator_node(const std::string& node_name, const node_context& external_context);
    virtual ~square_wave_generator_node() = default;

    // Attributes:
    virtual scale time_precision() const { return micro; }

    // Ports:
    port<flow, input, duration> period_dt_input;  // input waveform period
    port<flow, input, float64> duty_cycle_input;  // input duty cycle
    port<message, output, float64> y_output;      // output signal level

protected:
    // State Variables:
    duration period_dt;  // duration of one period of the square wave
    float64 duty_cycle;  // fraction (0 to 1) of each period spent in the "on" phase
    int64 phase;         // binary signal phase (0 => off, 1 => on)

    // Event Handlers:
    virtual duration initialization_event();
    virtual duration unplanned_event(duration elapsed_dt);
    virtual duration planned_event(duration elapsed_dt);
    virtual void finalization_event(duration elapsed_dt);
};


inline square_wave_generator_node::square_wave_generator_node(const std::string& node_name, const node_context& external_context)
    : atomic_node(node_name, external_context)
    , period_dt_input("period_dt_input", external_interface())
    , duty_cycle_input("duty_cycle_input", external_interface())
    , y_output("y_output", external_interface())
{
}


inline duration square_wave_generator_node::initialization_event()
{
    period_dt = period_dt_input.value().fixed_at(time_precision());
    duty_cycle = duty_cycle_input.value();
    phase = 1;
    return 0_s;
}


inline duration square_wave_generator_node::unplanned_event(duration elapsed_dt)
{
    return duration();
}


inline duration square_wave_generator_node::planned_event(duration elapsed_dt)
{
    duration planned_dt;
    if (phase == 0) {
        phase = 1;
        planned_dt = period_dt*duty_cycle;
    }
    else if (phase == 1) {
        phase = 0;
        planned_dt = period_dt*(1.0 - duty_cycle);
    }
    y_output.send(float64(phase));
    return planned_dt;
}


inline void square_wave_generator_node::finalization_event(duration elapsed_dt)
{
}


}  // namespace

#endif
