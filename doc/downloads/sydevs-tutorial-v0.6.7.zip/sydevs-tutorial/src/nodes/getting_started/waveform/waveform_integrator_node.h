#pragma once
#ifndef SYDEVS_TUTORIAL_WAVEFORM_INTEGRATOR_NODE_H_
#define SYDEVS_TUTORIAL_WAVEFORM_INTEGRATOR_NODE_H_

#include <sydevs/systems/atomic_node.h>

namespace sydevs_tutorial {

using namespace sydevs;
using namespace sydevs::systems;


class waveform_integrator_node : public atomic_node
{
public:
    // Constructor/Destructor:
    waveform_integrator_node(const std::string& node_name, const node_context& external_context);
    virtual ~waveform_integrator_node() = default;

    // Attributes:
    virtual scale time_precision() const { return micro; }

    // Ports:
    port<flow, input, duration> step_dt_input;   // time step for message output
    port<message, input, float64> y_input;       // input signal level
    port<message, output, float64> Y_output;     // integrated signal level
    port<flow, output, float64> Y_final_output;  // final integrated signal level

protected:
    // State Variables:
    duration step_dt;     // duration between successive output messages
    float64 y;            // current signal level
    float64 Y;            // current integrated level
    duration planned_dt;  // planned duration

    // Event Handlers:
    virtual duration initialization_event();
    virtual duration unplanned_event(duration elapsed_dt);
    virtual duration planned_event(duration elapsed_dt);
    virtual void finalization_event(duration elapsed_dt);
};


inline waveform_integrator_node::waveform_integrator_node(const std::string& node_name, const node_context& external_context)
    : atomic_node(node_name, external_context)
    , step_dt_input("step_dt_input", external_interface())
    , y_input("y_input", external_interface())
    , Y_output("Y_output", external_interface())
    , Y_final_output("Y_final_output", external_interface())
{
}


inline duration waveform_integrator_node::initialization_event()
{
    step_dt = step_dt_input.value().fixed_at(time_precision());
    y = 0.0;
    Y = 0.0;
    planned_dt = 0_s;
    return planned_dt;
}


inline duration waveform_integrator_node::unplanned_event(duration elapsed_dt)
{
    Y += y*(elapsed_dt/1_s);
    if (y_input.received()) {
        y = y_input.value();
    }
    planned_dt -= elapsed_dt;
    return planned_dt;
}


inline duration waveform_integrator_node::planned_event(duration elapsed_dt)
{
    Y += y*(elapsed_dt/1_s);
    Y_output.send(Y);
    planned_dt = step_dt;
    return planned_dt;
}


inline void waveform_integrator_node::finalization_event(duration elapsed_dt)
{
    Y += y*(elapsed_dt/1_s);
    Y_final_output.assign(Y);
}


}  // namespace

#endif
