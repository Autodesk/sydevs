#pragma once
#ifndef SYDEVS_TUTORIAL_SQUARE_WAVE_INTEGRATION_CLOSED_SYSTEM_H_
#define SYDEVS_TUTORIAL_SQUARE_WAVE_INTEGRATION_CLOSED_SYSTEM_H_

#include <nodes/getting_started/waveform/square_wave_generator_node.h>
#include <nodes/getting_started/waveform/waveform_integrator_node.h>
#include <sydevs/systems/composite_node.h>
#include <sydevs/systems/parameter_node.h>
#include <sydevs/systems/statistic_node.h>

namespace sydevs_tutorial {

using namespace sydevs;
using namespace sydevs::systems;


class square_wave_integration_closed_system : public composite_node
{
public:
    // Constructor/Destructor:
    square_wave_integration_closed_system(const std::string& node_name, const node_context& external_context);
    virtual ~square_wave_integration_closed_system() = default;

    // Ports:

    // Components:
    parameter_node<duration> period_dt;
    parameter_node<float64> duty_ratio;
    parameter_node<duration> integrator_step_dt;
    square_wave_generator_node generator;
    waveform_integrator_node integrator;
    statistic_node<float64> Y_final;
};


square_wave_integration_closed_system::square_wave_integration_closed_system(const std::string& node_name, const node_context& external_context)
    : composite_node(node_name, external_context)
    , period_dt("period_dt", internal_context(), 10_s)
    , duty_ratio("duty_ratio", internal_context(), 0.5)
    , integrator_step_dt("integrator_step_dt", internal_context())
    , generator("generator", internal_context())
    , integrator("integrator", internal_context())
    , Y_final("Y_final", internal_context())
{
    // Initialization Links:
    inner_link(period_dt.parameter, generator.period_dt_input);
    inner_link(duty_ratio.parameter, generator.duty_cycle_input);
    inner_link(integrator_step_dt.parameter, integrator.step_dt_input);

    // Simulation Links:
    inner_link(generator.y_output, integrator.y_input);

    // Finalization Links:
    inner_link(integrator.Y_final_output, Y_final.statistic);
}


}  // namespace

#endif
