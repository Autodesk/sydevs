#include <nodes/getting_started/waveform/square_wave.h>

int main(int argc, const char* argv[])
{
    sydevs_tutorial::simulate_square_wave_closed_system();
    return 0;
}
