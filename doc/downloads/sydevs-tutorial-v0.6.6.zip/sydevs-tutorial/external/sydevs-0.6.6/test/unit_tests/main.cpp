//
//  main.cpp
//  tests
//
//  Created by bwk on 11.05.15.
//  Copyright (c) 2015 php. All rights reserved.
//

// This tells Catch to provide a main() - only do this in one cpp file
#define CATCH_CONFIG_MAIN

#include <catch2/catch.hpp>
