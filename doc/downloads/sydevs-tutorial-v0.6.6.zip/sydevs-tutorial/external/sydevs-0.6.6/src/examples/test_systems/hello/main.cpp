#include <examples/test_systems/hello/hello_systems.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::hello_systems();
    return 0;
}
