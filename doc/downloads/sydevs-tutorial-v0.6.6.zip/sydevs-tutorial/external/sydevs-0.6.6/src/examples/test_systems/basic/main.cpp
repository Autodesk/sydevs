#include <examples/test_systems/basic/basic_systems.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::basic_systems();
    return 0;
}
