#include <examples/research/subtyping/subtyping.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::subtyping();
    return 0;
}
