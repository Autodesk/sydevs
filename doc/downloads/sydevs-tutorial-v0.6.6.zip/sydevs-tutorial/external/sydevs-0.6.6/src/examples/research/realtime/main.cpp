#include <examples/research/realtime/realtime.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::realtime rt;
    rt.mainloop();
    return 0;
}
