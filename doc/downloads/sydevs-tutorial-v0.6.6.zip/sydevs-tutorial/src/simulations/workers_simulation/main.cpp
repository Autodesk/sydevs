// The "workers" demonstration project provides a simple example of 
// agent-based modeling

#include <nodes/demo/workers/workers.h>

int main(int argc, const char* argv[])
{
    sydevs_examples::workers();
    return 0;
}
