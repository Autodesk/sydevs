#pragma once
#ifndef SYDEVS_TUTORIAL_SQUARE_WAVE_H_
#define SYDEVS_TUTORIAL_SQUARE_WAVE_H_

#include <nodes/getting_started/waveform/square_wave_closed_system.h>
#include <nodes/getting_started/waveform/square_wave_integration_closed_system.h>
#include <sydevs/systems/simulation.h>
#include <iostream>

namespace sydevs_tutorial {

using namespace sydevs;
using namespace sydevs::systems;


void simulate_square_wave_closed_system()
{
    try {
        simulation<square_wave_closed_system> sim(1_min, 0, std::cout);
        sim.top.print_on_event();
        sim.process_remaining_events();
    }
    catch (const system_node::error& e) {
        std::cout << "SYSTEM NODE ERROR: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "OTHER ERROR: " << e.what() << std::endl;
    }
}


void simulate_square_wave_integration_closed_system()
{
    try {
        simulation<square_wave_integration_closed_system> sim(1_min, 0, std::cout);
        sim.top.period_dt.set_value(10_s);
        sim.top.duty_ratio.set_value(0.3);
        sim.top.integrator_step_dt.set_value(1500_ms);
        sim.top.generator.y_output.print_on_use();
        sim.top.integrator.Y_output.print_on_use();
        sim.process_remaining_events();
        float64 Y_final = sim.top.Y_final.value();
        std::cout << "Y_final = " << Y_final << std::endl;
    }
    catch (const system_node::error& e) {
        std::cout << "SYSTEM NODE ERROR: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "OTHER ERROR: " << e.what() << std::endl;
    }
}


}  // namespace

#endif