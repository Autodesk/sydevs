var searchData=
[
  ['yocto_669',['yocto',['../namespacesydevs.html#ab33aef035a01c5936c36198bb76839ec',1,'sydevs']]],
  ['yotta_670',['yotta',['../namespacesydevs.html#ad2cf1c7f9bea8da393be229c51a3d68e',1,'sydevs']]]
];
