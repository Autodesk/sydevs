var identity_8h =
[
    [ "identity", "classsydevs_1_1identity.html", "classsydevs_1_1identity" ],
    [ "SYDEVS_IDENTITY_H_", "identity_8h.html#a828a16df18cb8cd92c03b1d1f4a2a171", null ],
    [ "operator+", "identity_8h.html#aaf24954a5b1963e2341996cc9e603448", null ],
    [ "operator<<", "identity_8h.html#a2bcde152995c52f5ce03f06165cec382", null ]
];