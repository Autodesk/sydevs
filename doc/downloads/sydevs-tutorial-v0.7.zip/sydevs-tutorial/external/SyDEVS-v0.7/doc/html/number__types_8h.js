var number__types_8h =
[
    [ "SYDEVS_NUMBER_TYPES_H_", "number__types_8h.html#af1378e32599b19d72c28f776626713f2", null ],
    [ "float32", "number__types_8h.html#ac6931fd355a1674333ac66119365fe09", null ],
    [ "float64", "number__types_8h.html#a6ad89989cc401c02d2e6280a59686c31", null ],
    [ "int16", "number__types_8h.html#a0142ae3b3b9fadbc415054ac62fb72dc", null ],
    [ "int32", "number__types_8h.html#a36e27cd6a25080ba3887c945713ebe84", null ],
    [ "int64", "number__types_8h.html#ad6a8f0e4a4fad0df62be1cb702f25de7", null ],
    [ "int8", "number__types_8h.html#a4449410aa44896979a15414f25776046", null ],
    [ "uint16", "number__types_8h.html#a1e401fdb858ed7ce91f64d5d482a9394", null ],
    [ "uint32", "number__types_8h.html#a3d0df03cee0f58ec6e2b2c7d9b7830ed", null ],
    [ "uint64", "number__types_8h.html#a913b6fe896d775b53267b04b3505e8c3", null ],
    [ "uint8", "number__types_8h.html#a7e22f638d7cd0efc74a06e359b42779e", null ],
    [ "pi", "number__types_8h.html#aec6503d6cc382f4da4d68703d1cdc843", null ]
];