var pointer_8h =
[
    [ "pointer", "classsydevs_1_1pointer.html", "classsydevs_1_1pointer" ],
    [ "SYDEVS_POINTER_H_", "pointer_8h.html#a1e4cf1c654fc5045c932334109fa62d2", null ]
];