var searchData=
[
  ['message_5fport_5fproxy_721',['message_port_proxy',['../classsydevs_1_1systems_1_1collection__node_1_1message__port__proxy.html',1,'sydevs::systems::collection_node']]]
];
