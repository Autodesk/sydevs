var searchData=
[
  ['data_5fgoal_1396',['data_goal',['../namespacesydevs_1_1systems.html#add51536d479991dea5779172e185bacc',1,'sydevs::systems']]],
  ['data_5fmode_1397',['data_mode',['../namespacesydevs_1_1systems.html#a1852ea7ca1d57fd679e01369acb054b8',1,'sydevs::systems']]]
];
