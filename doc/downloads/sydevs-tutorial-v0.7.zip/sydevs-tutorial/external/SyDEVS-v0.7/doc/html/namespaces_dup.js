var namespaces_dup =
[
    [ "std", "namespacestd.html", "namespacestd" ],
    [ "sydevs", "namespacesydevs.html", "namespacesydevs" ]
];