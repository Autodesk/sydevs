var node__context_8h =
[
    [ "node_context", "classsydevs_1_1systems_1_1node__context.html", "classsydevs_1_1systems_1_1node__context" ],
    [ "SYDEVS_SYSTEMS_NODE_CONTEXT_H_", "node__context_8h.html#af88d011e67ae81177007b0ab094e20ca", null ]
];