var searchData=
[
  ['k_5f_215',['K_',['../structsydevs_1_1units.html#a2244ddeda2e100c8d23c27d841542c74a0f8a20b0b0d423ccba15c10419d931fb',1,'sydevs::units']]],
  ['kelvins_216',['kelvins',['../namespacesydevs.html#a2085707f43458573dbafc0e8948eae7c',1,'sydevs']]],
  ['kilo_217',['kilo',['../namespacesydevs.html#a025c3d68c20f62cb2b02c09eaff7084a',1,'sydevs']]]
];
