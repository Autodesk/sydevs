var data__goal_8h =
[
    [ "SYDEVS_SYSTEMS_DATA_GOAL_H_", "data__goal_8h.html#aec5e0192291126f9d313bfc0b4283c87", null ],
    [ "data_goal", "data__goal_8h.html#add51536d479991dea5779172e185bacc", [
      [ "input", "data__goal_8h.html#add51536d479991dea5779172e185baccaa43c1b0aa53a0c908810c06ab1ff3967", null ],
      [ "output", "data__goal_8h.html#add51536d479991dea5779172e185bacca78e6221f6393d1356681db398f14ce6d", null ]
    ] ],
    [ "data_goal_from_string", "data__goal_8h.html#acbb38ce2a68442030fef244a8669c6b7", null ],
    [ "int64_from_data_goal", "data__goal_8h.html#a7051406ddac71bcba2207d89bf0fdcd9", null ],
    [ "string_from_data_goal", "data__goal_8h.html#a1662f027c1db345bd2749650f7df28f4", null ],
    [ "input", "data__goal_8h.html#ad0d79287f2ae06535c27abf4bddcaba6", null ],
    [ "output", "data__goal_8h.html#a90d7a22c39ca9f9cdb404e4b3f04caba", null ]
];