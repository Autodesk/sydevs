var data__goal_8cpp =
[
    [ "data_goal_from_string", "data__goal_8cpp.html#acbb38ce2a68442030fef244a8669c6b7", null ],
    [ "string_from_data_goal", "data__goal_8cpp.html#a1662f027c1db345bd2749650f7df28f4", null ],
    [ "data_goal_strings", "data__goal_8cpp.html#a4f7630d7ddd0bdcd29abc121e660eba3", null ],
    [ "data_goals", "data__goal_8cpp.html#a362ca2c8c2a768d6956b1a9aaa8551c9", null ]
];