var collection__node__base_8h =
[
    [ "collection_node_base", "classsydevs_1_1systems_1_1collection__node__base.html", "classsydevs_1_1systems_1_1collection__node__base" ],
    [ "SYDEVS_SYSTEMS_COLLECTION_NODE_BASE_H_", "collection__node__base_8h.html#aea0f388883c2080ea26fb9db546eba15", null ]
];